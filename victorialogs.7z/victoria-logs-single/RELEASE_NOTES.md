# Release notes for version 0.8.1

**Release date:** 2024-11-08

![AppVersion: v0.41.0](https://img.shields.io/static/v1?label=AppVersion&message=v0.41.0&color=success&logo=)
![Helm: v3](https://img.shields.io/static/v1?label=Helm&message=v3&color=informational&logo=helm)

- updated common dependency 0.0.21 -> 0.0.23
- added `log.message` to a list of default vector message fields

