# Release notes for version 0.0.23

**Release date:** 2024-11-08

![Helm: v3](https://img.shields.io/static/v1?label=Helm&message=v3&color=informational&logo=helm)

- fix: context cleanup

