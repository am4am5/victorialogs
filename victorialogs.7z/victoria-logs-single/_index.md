---
weight: 1
title: VictoriaLogs Single
menu:
  docs:
    parent: helm
    weight: 1
    identifier: helm-victorialogs-single
url: /helm/victorialogs-single
aliases:
  - /helm/victorialogs-single/index.html
---
{{% content "README.md" %}}
