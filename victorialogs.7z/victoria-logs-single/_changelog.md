---
weight: 1
title: CHANGELOG
menu:
  docs:
    weight: 1
    identifier: helm-victorialogs-single-changelog
    parent: helm-victorialogs-single
url: /helm/victorialogs-single/changelog
aliases:
  - /helm/victorialogs-single/changelog/index.html
---
{{% content "CHANGELOG.md" %}}
